﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CookieClicked : MonoBehaviour
{
	public void CookieWasClicked()
    {
        //Just used for debuging
        Debug.Log("Cookie Was Clicked");
    }
    
}
